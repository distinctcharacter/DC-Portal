(() => {
  const state = { scenario: "client", resourceFilter: "all" };

  const protocolDefinitions = [
    {
      id: "DC-P01-SBP",
      title: "Somatic Baseline Protocol",
      phase: "Phase 1",
      progress: 42,
      copy: "The biological foundation for behavioral governance. Establish nervous system literacy, baseline regulation, and a repeatable return-to-command practice.",
      next: "Complete a zone check and log one tactical reset.",
      tools: [
        ["Somatic Dysregulation Index", "Assessment", "Baseline and exit comparison for regulation capacity."],
        ["Nervous System Zone Selector", "Tracker", "Low-friction recognition of current operating state."],
        ["Environmental Friction Map", "Worksheet", "Identify conditions that repeatedly increase allostatic load."],
        ["Tactical Reset Practice Tracker", "Tracker", "Record reset selection and resulting capacity shift."],
        ["Daily Governance Log", "Ledger", "Track state, context, intervention, and governed next action."],
        ["Relapse & Re-Entry Ledger", "Ledger", "Support non-punitive return after dysregulation or interruption."]
      ]
    },
    {
      id: "DC-P02-COG",
      title: "Cognitive Architecture",
      phase: "Phase 2",
      progress: 0,
      copy: "A three-part identity and interpretation system. IOS-1, MES-1, and NCS-1 make inherited automation visible before deliberate re-governance.",
      next: "Requires Somatic Baseline completion.",
      children: ["IOS-1 Identity Operating System", "MES-1 Masking Economy System", "NCS-1 Narrative Control System"],
      tools: [
        ["IOS-1 Completion Checkpoints", "Progress Gate", "Protect the handwritten identity process without reducing it to digital completion."],
        ["Identity Synthesis Capture", "Synthesis", "Record final identity-level observations after reflective work."],
        ["Mask Registry", "Portal Tool", "Identify adaptation patterns, context, cost, and current necessity."],
        ["Mask Cost Calculator", "Calculator", "Evaluate the resource extraction associated with masking."],
        ["Narrative Pattern Mapper", "Portal Tool", "Consolidated prompt flow for interpretation architecture."],
        ["Seven Distortion Types Profile", "Assessment", "Classify recurring distortions without excessive tables."],
        ["14-Day Override Application Tracker", "Tracker", "Measure application after narrative calibration."]
      ]
    },
    {
      id: "DC-P03-EXE",
      title: "Execution Architecture",
      phase: "Phase 3",
      progress: 0,
      copy: "A governed execution engine for consistent action without chronic urgency, depletion, emotional override, or biological debt.",
      next: "Requires Cognitive Architecture completion.",
      tools: [
        ["Somatic Execution Audit", "Assessment", "Identify where execution is operating against biological reality."],
        ["Decision Protocol Tool", "Tool", "Close open loops with deliberate decision criteria."],
        ["Friction Reduction Map", "Worksheet", "Locate and reduce normalized operational friction."],
        ["Execution Loop Builder", "Builder", "Design an execution model that survives fluctuating capacity."],
        ["Capacity Ledger", "Ledger", "Track the relationship between demand, capacity, and completion."]
      ]
    },
    {
      id: "DC-P04-REL",
      title: "Relational Command",
      phase: "Phase 4",
      progress: 0,
      copy: "Authority Framework followed by Internal Signal Calibration: relational governance, soft power, signal fidelity, and titrated action.",
      next: "Requires Execution Architecture completion.",
      children: ["Authority Framework", "Internal Signal Calibration"],
      tools: [
        ["Communication Persona Assessment", "Assessment", "Identify communication patterns under relational pressure."],
        ["Integrity Compass Filter", "Tool", "Separate governed alignment from appeasement or reactive force."],
        ["Boundary / Soft Ask / Conflict Script Builder", "Builder", "Prepare precise language before high-load conversations."],
        ["Zone 1 Readiness Check", "Assessment", "Confirm sufficient capacity before signal interpretation."],
        ["Intuitive Decision Matrix", "Matrix", "Evaluate internal signal, context, cost, and appropriate action."],
        ["Law of Titration Micro-Action Tracker", "Tracker", "Build signal fidelity through scaled implementation."]
      ]
    },
    {
      id: "DC-P06-SOV",
      title: "30-Day Sovereignty Reset",
      phase: "Phase 6",
      progress: 0,
      copy: "A timed implementation container that turns comprehension into daily biological, relational, and behavioral integration.",
      next: "Requires Relational Command completion.",
      tools: [
        ["Hard vs Soft Power Baseline Audit", "Assessment", "Establish the starting power pattern before the reset."],
        ["Daily Reset Tracker", "Timed Tracker", "Track daily application through the 30-day progression."],
        ["Boundary Execution Toolkit", "Toolkit", "Support deliberate relational implementation."],
        ["Identity Anchor Builder", "Builder", "Stabilize identity-level standards during integration."],
        ["90-Day Integration Plan", "Planner", "Extend reset gains beyond the initial timed container."]
      ]
    },
    {
      id: "DC-P07-SMB",
      title: "Self-Mastery Blueprint",
      phase: "Phase 7",
      progress: 0,
      copy: "The flagship capstone: a governed life architecture command center integrating biological, cognitive, relational, and execution systems.",
      next: "Requires 30-Day Sovereignty Reset final audit.",
      tools: [
        ["Baseline / Closing Self-Assessment", "Assessment", "Compare system-level changes at entry and close."],
        ["Governed Life Vision Builder", "Builder", "Translate integrated standards into life architecture."],
        ["Biological Tracker Suite", "Tracker Suite", "Track food-mood-energy, movement, sleep, and regulation practices."],
        ["Weekly Alignment Check-In", "Tracker", "Review integration without perfectionistic monitoring."],
        ["Daily Micro-Adjustment Protocol", "Tracker", "Support small governed corrections in real conditions."],
        ["Blueprint Master-Plan Builder", "Builder", "Generate the final self-mastery operating plan."],
        ["Final Blueprint Export", "Generated PDF", "Create a durable personal command document."]
      ]
    },
    {
      id: "DC-P08-EIP",
      title: "Enterprise IP Mastermind",
      phase: "Tier 3 Commercial Incubation",
      progress: 0,
      copy: "A premium commercial incubation environment for converting self-mastery, expertise, and framework logic into protectable and licensable intellectual property.",
      next: "Separate high-ticket purchase. Core portal completion informs readiness.",
      tools: [
        ["Commercial Readiness Assessment", "Assessment", "Evaluate readiness for intellectual property incubation."],
        ["IP Asset Inventory", "Registry", "Classify existing knowledge, assets, frameworks, and delivery methods."],
        ["Framework Encoding Builder", "Builder", "Convert tacit expertise into teachable system logic."],
        ["Offer Architecture Builder", "Builder", "Translate encoded IP into delivery-ready offers."],
        ["Pricing Mechanics Calculator", "Calculator", "Model pricing by rights, depth, access, and support."],
        ["Licensing Rights Matrix", "Matrix", "Separate usage, delivery, modification, and resale permissions."],
        ["12-Month Commercial Incubation Roadmap", "Planner", "Sequence legal, product, sales, and implementation work."],
        ["Final IP Commercialization Brief", "Generated PDF", "Export the commercialization architecture."]
      ]
    }
  ];

  const resources = [
    ["DC-R01-BIC", "Biological Infrastructure Companion", "Foundation", "foundation", "Client + Practitioner", "available", "Reference architecture for body, energy, recovery, and nervous system governance."],
    ["DC-R02-12W", "12 Dimensions of Wellness", "Foundation", "foundation", "Client + Practitioner", "available", "A multidimensional reference map for physical, relational, identity, boundary, and self-efficacy signals."],
    ["DC-R03-GLO", "Distinct Character Framework Glossary", "Foundation", "foundation", "Client + Practitioner", "design", "Standard definitions for behavioral governance, biological realism, authority, masking economy, and signal calibration."],
    ["DC-R04-BSI", "Body Signal Index", "Foundation", "foundation", "Client + Practitioner", "design", "A concise index extracted from the Biological Infrastructure Companion for lower-friction reference."],
    ["DC-R05-NSG", "Nervous System Governance Reference", "Foundation", "foundation", "Client + Practitioner", "design", "A practical field reference for reading activation, shutdown, stabilization, and return-to-command signals."],
    ["DC-P01-SBP-CM01", "Somatic Baseline Companion Materials", "Somatic Baseline", "protocol", "Client + Practitioner", "available", "The canonical SBP support resource: research guide, integration exercises, quick reference guide, and optional deepening paths."],
    ["DC-P01-SBP-MAP01", "Environmental Friction Map", "Somatic Baseline", "toolkit", "Client", "design", "A portal-native and printable map for identifying repeated sources of allostatic cost."],
    ["DC-P01-SBP-LED01", "Relapse & Re-Entry Ledger", "Somatic Baseline", "toolkit", "Client", "design", "A printable and interactive tool supporting non-punitive return after dysregulation."],
    ["DC-P02-IOS-CM01", "IOS-1 Companion Materials", "Identity Operating System", "protocol", "Client + Practitioner", "available", "The canonical IOS-1 support resource: research guide, integration exercises, quick reference guide, and optional deepening paths."],
    ["DC-P02-IOS-RG01", "Sovereign Framework Glossary", "Identity Operating System", "protocol", "Client + Practitioner", "design", "Identity architecture terms extracted from IOS-1 and standardized for reference use."],
    ["DC-P02-MES-CM01", "MES-1 Companion Materials", "Masking Economy System", "protocol", "Client + Practitioner", "available", "The canonical MES-1 support resource: research guide, integration exercises, quick reference guide, and optional deepening paths."],
    ["DC-P02-MES-RET01", "Mask Retirement Protocol", "Masking Economy System", "toolkit", "Client", "design", "A structured retirement path for adaptations that are no longer operationally necessary."],
    ["DC-P02-NCS-CM01", "NCS-1 Companion Materials", "Narrative Control System", "protocol", "Client + Practitioner", "available", "The canonical NCS-1 support resource: research guide, integration exercises, quick reference guide, and optional deepening paths."],
    ["DC-P02-NCS-OS01", "Override Script Library", "Narrative Control System", "toolkit", "Client", "design", "A consolidated application library for deliberate interpretation governance."],
    ["DC-P03-EXE-FR01", "Friction Reduction Map", "Execution Architecture", "toolkit", "Client", "design", "A practical worksheet for identifying and reducing normalized execution friction."],
    ["DC-P04-REL-BND01", "Relational Command Bundle Overview", "Relational Command", "protocol", "Client + Practitioner", "design", "Orientation guide linking Authority Framework and Internal Signal Calibration in the correct sequence."],
    ["DC-P04-AUT-SCR01", "Boundary / Soft Ask / Conflict Script Builder", "Authority Framework", "toolkit", "Client", "design", "A structured language tool for relational implementation under pressure."],
    ["DC-P06-SOV-BND01", "Boundary Execution Toolkit", "30-Day Sovereignty Reset", "toolkit", "Client", "design", "A practical implementation resource for the timed reset."],
    ["DC-P06-SOV-90D01", "90-Day Integration Plan", "30-Day Sovereignty Reset", "toolkit", "Client", "design", "A post-reset plan for sustaining standards after the 30-day container."],
    ["DC-P07-SMB-MP01", "Blueprint Master-Plan Builder", "Self-Mastery Blueprint", "toolkit", "Client", "design", "The capstone builder for integrated biological, cognitive, relational, and execution architecture."],
    ["DC-P08-IPM", "IP Licensing & Monetization Architecture", "Enterprise IP Mastermind", "commercial", "Commercial Incubation Client", "commercial", "The companion commercial framework for structuring, pricing, protecting, and selling digital assets using soft power."],
    ["DC-P08-EIP-ADV01", "Commercial Facilitator / Legal-Ops Guide", "Enterprise IP Mastermind", "commercial", "Advisor + Admin", "commercial", "Controlled implementation guide requiring legal, operational, and financial review."],
    ["DC-P01-SBP-TA01", "Somatic Baseline Therapeutic Addendum", "Somatic Baseline", "practitioner", "Practitioner", "practitioner", "Safety, pacing, scope, and therapeutic-adjacent implementation guidance."],
    ["DC-P02-IOS-TA01", "IOS-1 Session Directives for Clinical Partnership", "Identity Operating System", "practitioner", "Practitioner", "practitioner", "Session directives supporting handwritten identity work within appropriate scope."],
    ["DC-P02-MES-TA01", "MES-1 Therapeutic Addendum", "Masking Economy System", "practitioner", "Practitioner", "practitioner", "Implementation guidance for observing adaptation cost without forcing unsafe unmasking."],
    ["DC-P02-NCS-TA01", "NCS-1 Therapeutic Addendum", "Narrative Control System", "practitioner", "Practitioner", "practitioner", "Clinical-adjacent notes for interpretation review, calibration, and pacing."],
    ["DC-P03-EXE-TA01", "Execution Therapeutic Addendum", "Execution Architecture", "practitioner", "Practitioner", "practitioner", "Pacing notes for execution work involving urgency, override, perfectionism, or depletion."],
    ["DC-P04-AUT-TA01", "Authority Practitioner Addendum", "Authority Framework", "practitioner", "Practitioner", "practitioner", "Scope-aware relational command implementation guidance."],
    ["DC-P04-ISC-TA01", "Internal Signal Therapeutic Addendum", "Internal Signal Calibration", "practitioner", "Practitioner", "practitioner", "Signal distortion, allostatic load, readiness, and titration guidance."],
    ["DC-P06-SOV-TA01", "Sovereignty Reset Therapeutic Addendum", "30-Day Sovereignty Reset", "practitioner", "Practitioner", "practitioner", "Four-week pacing, facilitation, and integration guidance."],
    ["DC-P07-SMB-TA01", "Self-Mastery Blueprint Therapeutic Addendum", "Self-Mastery Blueprint", "practitioner", "Practitioner", "practitioner", "Capstone integration notes for complex system-level implementation."]
  ].map(([id, title, parent, group, audience, access, copy]) => ({ id, title, parent, group, audience, access, copy }));

  const downloads = [
    ["DC-P01-SBP-CM01", "Somatic Baseline Companion Materials", "Somatic Baseline", "Unified Companion Resource", "client"],
    ["DC-P01-SBP-AS01", "Somatic Dysregulation Index", "Somatic Baseline", "Assessment", "client"],
    ["DC-P01-SBP-LOG01", "Daily Governance Log", "Somatic Baseline", "Ledger", "client"],
    ["DC-P02-IOS-PC01", "IOS-1 Handwritten Printable Companion", "Cognitive Architecture", "Printable Companion", "phase"],
    ["DC-P02-IOS-CM01", "IOS-1 Companion Materials", "Identity Operating System", "Unified Companion Resource", "phase"],
    ["DC-P02-MES-PC01", "MES-1 Printable Companion", "Cognitive Architecture", "Printable Companion", "phase"],
    ["DC-P02-MES-CM01", "MES-1 Companion Materials", "Masking Economy System", "Unified Companion Resource", "phase"],
    ["DC-P02-NCS-PC01", "NCS-1 Printable Companion", "Cognitive Architecture", "Printable Companion", "phase"],
    ["DC-P02-NCS-CM01", "NCS-1 Companion Materials", "Narrative Control System", "Unified Companion Resource", "phase"],
    ["DC-P03-EXE-PC01", "Execution Architecture Printable Companion", "Execution Architecture", "Printable Companion", "phase"],
    ["DC-P04-AUT-PC01", "Authority Framework Printable Companion", "Relational Command", "Printable Companion", "phase"],
    ["DC-P04-ISC-PC01", "Internal Signal Calibration Printable Companion", "Relational Command", "Printable Companion", "phase"],
    ["DC-P06-SOV-PC01", "30-Day Sovereignty Reset Printable Companion", "Sovereignty Reset", "Printable Companion", "phase"],
    ["DC-P06-SOV-90D01", "90-Day Integration Plan", "Sovereignty Reset", "Planner", "phase"],
    ["DC-P07-SMB-PC01", "Self-Mastery Blueprint Printable Companion", "Self-Mastery Blueprint", "Printable Companion", "phase"],
    ["DC-P07-SMB-EX01", "Final Blueprint Export", "Self-Mastery Blueprint", "Generated Export", "phase"],
    ["DC-P08-EIP-PC01", "Enterprise IP Executive Field Manual", "Enterprise IP Mastermind", "Printable Companion", "commercial"],
    ["DC-P08-EIP-BRIEF01", "Final IP Commercialization Brief", "Enterprise IP Mastermind", "Generated Export", "commercial"],
    ["DC-P01-SBP-TA01", "Somatic Baseline Therapeutic Addendum", "Practitioner Layer", "Practitioner Resource", "practitioner"],
    ["DC-P04-ISC-TA01", "Internal Signal Therapeutic Addendum", "Practitioner Layer", "Practitioner Resource", "practitioner"],
    ["DC-P06-SOV-TA01", "Sovereignty Reset Therapeutic Addendum", "Practitioner Layer", "Practitioner Resource", "practitioner"]
  ].map(([id, title, parent, type, access]) => ({ id, title, parent, type, access }));

  const isFullClientReview = () => state.scenario === "fullClient";
  const hasPractitionerPurchase = () => state.scenario === "practitioner";
  const protocolIsUnlocked = protocol => protocol.id === "DC-P01-SBP" || isFullClientReview();

  const protocolCard = protocol => {
    const unlocked = protocolIsUnlocked(protocol);
    const cardStatus = protocol.id === "DC-P01-SBP" && !isFullClientReview() ? "active" : unlocked ? "available" : "locked";
    const action = unlocked ? (protocol.id === "DC-P01-SBP" ? "Continue protocol" : "Open protocol") : "Review locked state";
    return `
      <article class="protocol-card ${unlocked ? "" : "is-locked"}">
        <div class="card-top"><span class="asset-id">${protocol.id}</span><span class="badge ${cardStatus}">${cardStatus === "active" ? "In Progress" : cardStatus === "available" ? "Unlocked" : "Locked"}</span></div>
        <h3>${protocol.title}</h3>
        <p>${protocol.copy}</p>
        ${protocol.children ? `<div class="chips">${protocol.children.map(child => `<span class="chip">${child}</span>`).join("")}</div>` : ""}
        <div class="bar"><span style="width:${protocol.id === "DC-P01-SBP" ? protocol.progress : 0}%"></span></div>
        <p class="next">${protocol.next}</p>
        <button class="btn ${unlocked ? "btn-primary" : "btn-secondary"}" data-open-protocol="${protocol.id}">${action}</button>
      </article>`;
  };

  const resourceAccess = resource => {
    if (resource.access === "practitioner") return hasPractitionerPurchase() ? ["purchased", "Practitioner Access"] : ["locked", "Practitioner Locked"];
    if (resource.access === "commercial") return isFullClientReview() ? ["controlled", "Controlled Access"] : ["locked", "Tier 3 Locked"];
    if (resource.access === "design") return ["design", "In Design"];
    return ["available", "Available"];
  };

  const resourceCard = resource => {
    const [accessClass, accessLabel] = resourceAccess(resource);
    return `
      <article class="resource-card">
        <div class="card-top"><span class="asset-id">${resource.id}</span><span class="badge ${accessClass}">${accessLabel}</span></div>
        <h3>${resource.title}</h3>
        <p>${resource.copy}</p>
        <dl><div><dt>Parent</dt><dd>${resource.parent}</dd></div><div><dt>Audience</dt><dd>${resource.audience}</dd></div></dl>
        <div class="actions"><button class="btn btn-secondary" data-resource-id="${resource.id}">${accessClass === "locked" ? "Review access state" : "Open resource preview"}</button></div>
      </article>`;
  };

  const getDownloadState = download => {
    if (download.access === "client") return ["available", "Available"];
    if (download.access === "phase") return isFullClientReview() ? ["available", "Available"] : ["locked", "Phase Locked"];
    if (download.access === "commercial") return isFullClientReview() ? ["controlled", "Controlled"] : ["locked", "Tier 3 Locked"];
    if (download.access === "practitioner") return hasPractitionerPurchase() ? ["purchased", "Available"] : ["locked", "Practitioner Locked"];
    return ["locked", "Locked"];
  };

  const showModal = (title, copy, eyebrow = "Access Architecture") => {
    document.querySelector("#modal-title").textContent = title;
    document.querySelector("#modal-copy").textContent = copy;
    document.querySelector("#modal-eyebrow").textContent = eyebrow;
    document.querySelector("#modal-backdrop").classList.add("show");
  };

  const renderResources = () => {
    const filtered = state.resourceFilter === "all" ? resources : resources.filter(resource => resource.group === state.resourceFilter);
    document.querySelector("#resource-library").innerHTML = filtered.map(resourceCard).join("");
    document.querySelector("#library-summary").innerHTML = `
      <div class="stat gold"><small>Library Architecture</small><strong>${resources.length}</strong><p>Approved resources represented</p></div>
      <div class="stat green"><small>Source Assets</small><strong>${resources.filter(resource => resource.access === "available").length}</strong><p>Submitted or extracted for standardization</p></div>
      <div class="stat blue"><small>Assets In Design</small><strong>${resources.filter(resource => resource.access === "design").length}</strong><p>Approved resources to author or rebuild</p></div>
      <div class="stat"><small>Controlled Layers</small><strong>${resources.filter(resource => ["practitioner", "commercial"].includes(resource.access)).length}</strong><p>Purchase or role-gated resources</p></div>`;
  };

  const renderDownloads = () => {
    document.querySelector("#download-center").innerHTML = `
      <div class="download-row header"><span>Asset</span><span>Protocol</span><span>Type</span><span>Status</span><span>Action</span></div>
      ${downloads.map(download => {
        const [statusClass, statusLabel] = getDownloadState(download);
        return `<div class="download-row">
          <span><strong>${download.title}</strong><small>${download.id}</small></span>
          <span>${download.parent}</span><span>${download.type}</span>
          <span class="badge ${statusClass}">${statusLabel}</span>
          <span><button class="review-button" data-download-id="${download.id}">${statusClass === "locked" ? "Review" : "Preview"}</button></span>
        </div>`;
      }).join("")}`;
  };

  const renderDashboard = () => {
    document.querySelector("#dashboard-protocols").innerHTML = protocolDefinitions.slice(0, 3).map(protocolCard).join("");
    document.querySelector("#dashboard-stats").innerHTML = `
      <div class="stat gold"><small>Active Protocol</small><strong>DC-P01-SBP</strong><p>Biological Architecture in progress</p></div>
      <div class="stat green"><small>Protocol Completion</small><strong>42%</strong><p>Exit assessment remains gated</p></div>
      <div class="stat blue"><small>Current State</small><strong>Zone Check Due</strong><p>Log one regulation practice today</p></div>
      <div class="stat"><small>Resource Architecture</small><strong>${resources.length}</strong><p>Available, planned, and controlled assets visible</p></div>`;
  };

  const renderProtocolLibrary = () => {
    document.querySelector("#protocol-library").innerHTML = protocolDefinitions.map(protocolCard).join("");
  };

  const protocolDetail = protocol => {
    const unlocked = protocolIsUnlocked(protocol);
    return `
      <button class="back" data-view="protocols">Back to protocol library</button>
      <div class="protocol-overview">
        <div>
          <span class="eyebrow">${protocol.id} &middot; ${protocol.phase}</span>
          <h1>${protocol.title}</h1>
          <p class="reader-lead">${protocol.copy}</p>
          <div class="access-banner">
            <div>
              <span class="badge ${unlocked ? "available" : "locked"}">${unlocked ? "Protocol Unlocked" : "Protocol Locked"}</span>
              <p>${unlocked ? "This review scenario shows the approved portal-native architecture and printable companion relationship." : protocol.next}</p>
            </div>
            <div class="actions"><button class="btn ${unlocked ? "btn-primary" : "btn-secondary"}" data-protocol-action="${protocol.id}">${unlocked ? "Begin protocol preview" : "Review unlock requirement"}</button></div>
          </div>
          <div class="reader-card">
            <span class="eyebrow">Delivery Architecture</span>
            <h2>Protocol installation environment</h2>
            <p>Long-form orientation, psychologically sensitive reflection, and handwriting-dependent work remain in the printable companion where appropriate. Repeatable governance data, assessments, ledgers, calculators, and progress gates become portal-native.</p>
          </div>
          <div class="reader-card">
            <span class="eyebrow">Interactive Components</span>
            <h2>Approved portal tools</h2>
            <div class="tool-list">
              ${protocol.tools.map(tool => `<div class="tool-item"><div><strong>${tool[0]}</strong><small>${tool[2]}</small></div><span class="badge ${unlocked ? "design" : "locked"}">${unlocked ? tool[1] : "Locked"}</span></div>`).join("")}
            </div>
          </div>
        </div>
        <aside class="review-stack">
          <div class="panel">
            <span class="eyebrow">Sequence Position</span>
            <h3>${protocol.phase}</h3>
            <p>${protocol.next}</p>
          </div>
          <div class="panel">
            <span class="eyebrow">Printable Layer</span>
            <h3>Companion asset retained</h3>
            <p>Each protocol receives a standardized printable companion, personal letter from Azari Solenne, controlled front matter, and consistent section hierarchy.</p>
          </div>
          <div class="panel">
            <span class="eyebrow">Practitioner Layer</span>
            <h3>Therapeutic addendum controlled</h3>
            <p>Addenda remain purchase-gated and role-gated. Clients see only their protocol experience unless their implementation model includes practitioner support.</p>
          </div>
        </aside>
      </div>`;
  };

  const practitionerDashboard = () => `
    <div class="access-banner">
      <div><span class="badge purchased">Practitioner Access Purchased</span><p>Role and entitlement checks have passed. Therapeutic addenda and consent-aware client implementation data are available.</p></div>
      <div class="actions"><button class="btn btn-secondary" data-resource-filter-link="practitioner">Open practitioner resources</button></div>
    </div>
    <div class="practitioner-stats">
      <div class="stat gold"><small>Assigned Clients</small><strong>12</strong><p>Mock practitioner caseload</p></div>
      <div class="stat blue"><small>Reviews Due</small><strong>3</strong><p>Two weekly, one attention review</p></div>
      <div class="stat green"><small>Stable Progression</small><strong>8</strong><p>Clients advancing without flags</p></div>
      <div class="stat"><small>Addenda Available</small><strong>9</strong><p>Role-gated implementation resources</p></div>
    </div>
    <div class="practitioner-layout">
      <div>
        <div class="section-heading"><span class="eyebrow">Assigned Client Overview</span><h2>Implementation caseload</h2><p>Mock identifiers only. Progress and attention signals are visible; private reflective writing remains hidden by default.</p></div>
        <div class="roster">
          <div class="roster-row header"><span>Client</span><span>Active protocol</span><span>Progress</span><span>Attention</span><span>Action</span></div>
          <div class="roster-row"><span><strong>Client DC-104</strong><small>Practitioner-guided</small></span><span>Somatic Baseline Protocol</span><span>42%</span><span class="attention">Review due</span><span><button class="review-button" data-client-review-v2="dc-104">Open review</button></span></div>
          <div class="roster-row"><span><strong>Client DC-118</strong><small>Practitioner-guided</small></span><span>MES-1 Masking Economy</span><span>68%</span><span class="stable">Stable</span><span><button class="review-button" data-client-review-v2="dc-118">Open review</button></span></div>
          <div class="roster-row"><span><strong>Client DC-127</strong><small>Cohort reset</small></span><span>30-Day Sovereignty Reset</span><span>Day 16</span><span class="attention">Check pacing</span><span><button class="review-button" data-client-review-v2="dc-127">Open review</button></span></div>
          <div class="roster-row"><span><strong>Client DC-131</strong><small>Practitioner-guided</small></span><span>Execution Architecture</span><span>54%</span><span class="stable">Stable</span><span><button class="review-button" data-client-review-v2="dc-131">Open review</button></span></div>
        </div>
      </div>
      <aside class="review-stack">
        <div class="panel"><span class="eyebrow">Review Queue</span><h3>Attention signals</h3><div class="queue">
          <div class="queue-item"><strong>Client DC-104</strong><small>Zone 2 entries increased across three logs. Review pacing before the Environmental Audit unlocks.</small></div>
          <div class="queue-item"><strong>Client DC-127</strong><small>Boundary execution decreased during Week 3. Confirm that somatic decision work is not moving too quickly.</small></div>
          <div class="queue-item"><strong>Client DC-118</strong><small>Weekly mask audit due in two days.</small></div>
        </div></div>
        <div class="panel"><span class="eyebrow">Practitioner Resources</span><h3>Therapeutic addenda</h3><p>Nine protocol-specific implementation addenda are available inside the controlled resource library.</p><button class="btn btn-secondary" data-resource-filter-link="practitioner">Review addenda</button></div>
      </aside>
    </div>`;

  const practitionerClientReview = clientId => `
    <button class="back" data-practitioner-home-v2>Back to practitioner workspace</button>
    <div class="client-review-head"><div><span class="eyebrow">Consent-Aware Client Review</span><h1>${clientId.toUpperCase()}</h1><p>Somatic Baseline Protocol &middot; Practitioner-guided implementation</p></div><span class="badge practitioner">Mock client record</span></div>
    <div class="consent-note"><strong>Visibility boundary:</strong> protocol progress, assessment completion, shared summaries, and practitioner notes are visible. Private reflections remain hidden unless the client intentionally shares them.</div>
    <div class="review-columns">
      <div class="review-stack">
        <div class="panel"><span class="eyebrow">Protocol Progress</span><h2>Somatic Baseline installation</h2><div class="bar"><span style="width:42%"></span></div><div class="metric-list">
          <div class="metric-row"><span>Orientation</span><strong class="stable">Completed</strong></div><div class="metric-row"><span>SDI baseline assessment</span><strong class="stable">Completed</strong></div><div class="metric-row"><span>Biological Architecture</span><strong>In progress</strong></div><div class="metric-row"><span>Environmental Audit</span><strong class="attention">Locked</strong></div>
        </div></div>
        <div class="panel"><span class="eyebrow">Shared Governance Data</span><h2>Implementation snapshot</h2><div class="metric-list">
          <div class="metric-row"><span>SDI baseline submitted</span><strong>Yes</strong></div><div class="metric-row"><span>Most frequent logged state</span><strong>Zone 2: Sympathetic</strong></div><div class="metric-row"><span>Tactical reset entries</span><strong>6</strong></div><div class="metric-row"><span>Most effective reset</span><strong>Physiological Sigh</strong></div>
        </div><span class="visibility-label">Shared summary only</span></div>
        <div class="panel"><span class="eyebrow">Practitioner Note</span><h2>Session integration note</h2><div class="mock-form"><label>Observation<textarea>Client demonstrates improved state recognition but continues to move quickly toward action while activated. Review pacing before unlocking the Environmental Audit.</textarea></label><label>Visibility<select><option>Private practitioner note</option><option>Share with client</option><option>Admin review</option></select></label><button class="btn btn-primary" data-mock-save>Save mock note</button></div></div>
      </div>
      <aside class="review-stack">
        <div class="panel"><span class="eyebrow">Attention Signal</span><h3>Pacing review recommended</h3><p>Zone 2 logs increased across three entries. Confirm a workable baseline before progression.</p></div>
        <div class="panel"><span class="eyebrow">Therapeutic Addendum</span><h3>Somatic Baseline guidance</h3><p>Review safety considerations, pendulation, lower-risk contexts, and scope boundaries before assigning the Environmental Audit.</p><button class="btn btn-secondary" data-resource-id="DC-P01-SBP-TA01">Open addendum</button></div>
        <div class="panel"><span class="eyebrow">Private Reflection Access</span><h3>Not shared</h3><p>The client has not shared private journal entries. This is expected and does not block protocol review.</p></div>
      </aside>
    </div>`;

  const renderPractitioner = () => {
    const area = document.querySelector("#practitioner-content");
    const purchased = hasPractitionerPurchase();
    document.querySelector("#session-role").textContent =
      state.scenario === "client" ? "Role: Client" :
      state.scenario === "fullClient" ? "Role: Full Client Review" :
      purchased ? "Role: Practitioner · Purchased" : "Role: Practitioner · Locked";
    area.innerHTML = purchased ? practitionerDashboard() : `
      <div class="panel placeholder">
        <span class="badge locked">Purchase-Gated Practitioner Layer</span>
        <h2>Practitioner implementation access is not active.</h2>
        <p>This controlled workspace unlocks only after a practitioner purchases access and the practitioner entitlement is assigned to their account. Client purchase alone never exposes therapeutic addenda, assigned-client review tools, consent-aware summaries, or practitioner notes.</p>
        <button class="btn btn-secondary" data-practitioner-gate>Review practitioner access path</button>
      </div>`;
  };

  const renderAll = () => {
    renderDashboard();
    renderProtocolLibrary();
    renderResources();
    renderDownloads();
    renderPractitioner();
  };

  document.addEventListener("click", event => {
    const openProtocol = event.target.closest("[data-open-protocol]");
    if (openProtocol) {
      const protocol = protocolDefinitions.find(item => item.id === openProtocol.dataset.openProtocol);
      if (protocol.id === "DC-P01-SBP" && protocolIsUnlocked(protocol)) {
        window.activatePreviewView("sbp");
      } else {
        document.querySelector("#protocol-detail-content").innerHTML = protocolDetail(protocol);
        window.activatePreviewView("protocol-detail");
      }
    }
    const protocolAction = event.target.closest("[data-protocol-action]");
    if (protocolAction) {
      const protocol = protocolDefinitions.find(item => item.id === protocolAction.dataset.protocolAction);
      showModal(
        protocolIsUnlocked(protocol) ? `${protocol.title} preview` : `${protocol.title} remains locked`,
        protocolIsUnlocked(protocol)
          ? "This clickable prototype shows the approved architecture. The production build will open the first incomplete section, preserve sequential gates, and save portal-native governance data."
          : protocol.next
      );
    }
    const filter = event.target.closest("[data-resource-filter]");
    if (filter) {
      state.resourceFilter = filter.dataset.resourceFilter;
      document.querySelectorAll("[data-resource-filter]").forEach(button => button.classList.toggle("active", button === filter));
      renderResources();
    }
    const practitionerResourceLink = event.target.closest("[data-resource-filter-link]");
    if (practitionerResourceLink) {
      state.resourceFilter = practitionerResourceLink.dataset.resourceFilterLink;
      window.activatePreviewView("resources");
      document.querySelectorAll("[data-resource-filter]").forEach(button => button.classList.toggle("active", button.dataset.resourceFilter === state.resourceFilter));
      renderResources();
    }
    const resourceButton = event.target.closest("[data-resource-id]");
    if (resourceButton) {
      const resource = resources.find(item => item.id === resourceButton.dataset.resourceId);
      const [accessClass, accessLabel] = resourceAccess(resource);
      showModal(
        resource.title,
        accessClass === "locked"
          ? `${accessLabel}. This resource remains visible in the architecture so access rules can be reviewed before production.`
          : `${accessLabel}. This prototype confirms the resource location, parent protocol, audience, and delivery state. Final authored or standardized content will be inserted during implementation.`,
        resource.id
      );
    }
    const downloadButton = event.target.closest("[data-download-id]");
    if (downloadButton) {
      const download = downloads.find(item => item.id === downloadButton.dataset.downloadId);
      const [statusClass, statusLabel] = getDownloadState(download);
      showModal(
        download.title,
        statusClass === "locked"
          ? `${statusLabel}. The production portal will enforce the related purchase, phase, or practitioner entitlement before exposing this asset.`
          : `${statusLabel}. Download behavior is intentionally simulated in this review prototype; no production asset is being served yet.`,
        download.id
      );
    }
    if (event.target.closest("[data-practitioner-gate]")) {
      showModal("Practitioner access path", "The practitioner layer unlocks only after practitioner access is purchased and assigned. Production entitlement logic will verify role, purchase, and account status before allowing client review tools or therapeutic addenda.");
    }
    const clientReview = event.target.closest("[data-client-review-v2]");
    if (clientReview) document.querySelector("#practitioner-content").innerHTML = practitionerClientReview(clientReview.dataset.clientReviewV2);
    if (event.target.closest("[data-practitioner-home-v2]")) renderPractitioner();
    if (event.target.closest("[data-mock-save]")) showModal("Mock practitioner note saved", "This confirms the session note interaction. Production notes will retain visibility settings and audit metadata.", "Practitioner Note");
    if (event.target.closest("[data-close-modal]") || event.target.id === "modal-backdrop") document.querySelector("#modal-backdrop").classList.remove("show");
  });

  document.querySelector("#role-select").addEventListener("change", event => {
    state.scenario = event.target.value;
    renderAll();
  });

  renderAll();
})();
