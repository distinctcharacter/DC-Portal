const fs = require("fs");
const path = require("path");
const { pathToFileURL } = require("url");
const { chromium } = require("playwright");

async function capture(page, view, filename) {
  if (view) {
    await page.evaluate((nextView) => window.activatePreviewView(nextView), view);
    await page.waitForTimeout(120);
  }
  await page.screenshot({
    path: path.join(__dirname, "screenshots", filename),
    fullPage: true
  });
}

async function main() {
  fs.mkdirSync(path.join(__dirname, "screenshots"), { recursive: true });
  const browser = await chromium.launch({
    headless: true,
    executablePath: "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
  });
  const fileUrl = pathToFileURL(path.join(__dirname, "index.html")).href;

  const desktop = await browser.newPage({ viewport: { width: 1440, height: 1100 } });
  await desktop.goto(fileUrl);
  await desktop.waitForTimeout(250);
  await capture(desktop, null, "01-dashboard-desktop.png");
  await capture(desktop, "protocols", "02-protocol-library-desktop.png");
  await capture(desktop, "resources", "03-resource-library-desktop.png");
  await capture(desktop, "sbp", "04-somatic-baseline-desktop.png");
  await capture(desktop, "downloads", "13-download-center-desktop.png");
  await desktop.evaluate(() => {
    const select = document.querySelector("#role-select");
    select.value = "practitionerLocked";
    select.dispatchEvent(new Event("change", { bubbles: true }));
    window.activatePreviewView("practitioner");
  });
  await desktop.waitForTimeout(120);
  await desktop.screenshot({
    path: path.join(__dirname, "screenshots", "10-practitioner-locked-desktop.png"),
    fullPage: true
  });
  await desktop.evaluate(() => {
    const select = document.querySelector("#role-select");
    select.value = "practitioner";
    select.dispatchEvent(new Event("change", { bubbles: true }));
    window.activatePreviewView("practitioner");
  });
  await desktop.waitForTimeout(120);
  await desktop.screenshot({
    path: path.join(__dirname, "screenshots", "07-practitioner-dashboard-desktop.png"),
    fullPage: true
  });
  await desktop.evaluate(() => window.activatePreviewView("resources"));
  await desktop.click('[data-resource-filter="practitioner"]');
  await desktop.waitForTimeout(120);
  await desktop.screenshot({
    path: path.join(__dirname, "screenshots", "14-practitioner-resource-library-desktop.png"),
    fullPage: true
  });
  await desktop.evaluate(() => window.activatePreviewView("practitioner"));
  await desktop.click('[data-client-review-v2="dc-104"]');
  await desktop.waitForTimeout(120);
  await desktop.screenshot({
    path: path.join(__dirname, "screenshots", "08-practitioner-client-review-desktop.png"),
    fullPage: true
  });
  await desktop.evaluate(() => {
    const select = document.querySelector("#role-select");
    select.value = "fullClient";
    select.dispatchEvent(new Event("change", { bubbles: true }));
    window.activatePreviewView("protocols");
  });
  await desktop.click('#protocol-library [data-open-protocol="DC-P02-COG"]');
  await desktop.waitForTimeout(120);
  await desktop.screenshot({
    path: path.join(__dirname, "screenshots", "11-cognitive-architecture-detail-desktop.png"),
    fullPage: true
  });
  await capture(desktop, "masterclass", "12-masterclass-placeholder-desktop.png");

  const mobile = await browser.newPage({ viewport: { width: 390, height: 844 } });
  await mobile.goto(fileUrl);
  await mobile.waitForTimeout(250);
  await capture(mobile, null, "05-dashboard-mobile.png");
  await capture(mobile, "protocols", "06-protocol-library-mobile.png");
  await mobile.evaluate(() => {
    const select = document.querySelector("#role-select");
    select.value = "practitioner";
    select.dispatchEvent(new Event("change", { bubbles: true }));
    window.activatePreviewView("practitioner");
  });
  await mobile.waitForTimeout(120);
  await mobile.screenshot({
    path: path.join(__dirname, "screenshots", "09-practitioner-dashboard-mobile.png"),
    fullPage: true
  });

  await browser.close();
console.log("Rendered 14 preview screenshots.");
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
