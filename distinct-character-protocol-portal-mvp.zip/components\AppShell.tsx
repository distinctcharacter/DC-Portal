import Link from "next/link";
import { mockUser } from "@/data/mock";

const navItems = [
  { href: "/", label: "Dashboard" },
  { href: "/#protocols", label: "Protocols" },
  { href: "/#resources", label: "Resources" },
  { href: "/#downloads", label: "Downloads" },
  { href: "/#practitioner", label: "Practitioner" },
  { href: "/#masterclass", label: "Masterclass" }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="Primary navigation">
        <Link className="brand" href="/">
          <span className="brand-mark">DC</span>
          <span>
            <strong>Distinct Character</strong>
            <small>Protocol Portal</small>
          </span>
        </Link>
        <nav className="nav-list">
          {navItems.map((item) => (
            <Link href={item.href} key={item.href}>
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="role-card">
          <span className="eyebrow">Mock Session</span>
          <strong>{mockUser.name}</strong>
          <span>Role: {mockUser.role}</span>
        </div>
      </aside>
      <div className="main-frame">
        <header className="topbar">
          <div>
            <span className="eyebrow">Protected Portal Shell</span>
            <p>Mock access model. Supabase and payment gates are intentionally offline.</p>
          </div>
          <button className="button secondary" type="button">
            Account
          </button>
        </header>
        <main>{children}</main>
      </div>
    </div>
  );
}
