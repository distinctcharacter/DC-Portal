# Distinct Character Protocol Portal
# Master Asset Register v0.1

## Register Purpose

This register is the control document for the Distinct Character Protocol Portal asset system. It tracks every protocol, printable companion, portal-native tool, dashboard metric, practitioner/facilitator resource, licensing asset, and foundation resource.

Use this document as the source of truth while converting the PDF/DOCX ecosystem into the portal.

## Global Production Rules

- Every protocol receives `A Letter from Azari Solenne` after copyright/front matter.
- Use `protocol` for the full delivery experience.
- Use `printable companion` only for the PDF or print-oriented asset.
- Deep reflective, identity, somatic, and psychologically sensitive work may remain printable/handwritten.
- Repeated logs, assessments, calculators, trackers, dashboards, matrices, and progress gates become portal-native.
- Therapeutic addenda stay at the back of printable assets and become role-gated practitioner content in the portal.
- Commercial/legal resources require attorney, CPA, or qualified professional review where applicable.
- Asset IDs are permanent. Versions can change; IDs should not.

## Protocol ID System

| ID | Title | Portal Position | Type | Status |
|---|---|---|---|---|
| DC-P01-SBP | Somatic Baseline Protocol | Phase 1 | Core Protocol | Source reviewed |
| DC-P02-COG | Cognitive Architecture | Phase 2 | Parent Bundle | Source reviewed |
| DC-P02-IOS | Identity Operating System | Phase 2A | Child Protocol | Source reviewed |
| DC-P02-MES | Masking Economy System | Phase 2B | Child Protocol | Source reviewed |
| DC-P02-NCS | Narrative Control System | Phase 2C | Child Protocol | Source reviewed |
| DC-P03-EXE | Execution Architecture Protocol | Phase 3 | Core Protocol | Source reviewed |
| DC-P04-REL | Relational Command | Phase 4 | Parent Bundle | Source reviewed |
| DC-P04-AUT | Authority Framework | Phase 4A | Child Protocol | Source reviewed |
| DC-P04-ISC | Internal Signal Calibration | Phase 4B | Child Protocol | Source reviewed |
| DC-P06-SOV | 30-Day Sovereignty Reset | Phase 6 | Core Protocol / Timed Reset | Source reviewed |
| DC-P07-SMB | Self-Mastery Blueprint | Phase 7 | Flagship Capstone | Source reviewed |
| DC-P08-EIP | Enterprise IP Mastermind | Tier 3 | Commercial Incubation | Notes reviewed |
| DC-P08-IPM | IP Licensing & Monetization Architecture | Tier 3 Companion | Commercial Framework | Notes reviewed |
| DC-P09-AAS | Advanced Application Series | Expansion Layer | Future Series | Placeholder |

## Foundation Resources

| Asset ID | Asset Title | Parent | Audience | Format | Portal Location | Printable | Downloadable | Access | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-R01-BIC | Biological Infrastructure Companion | Foundation | Client + Practitioner | PDF / Portal Reference | Resource Library | Yes | Yes | Purchased protocol users | v1.0 pending | Source reviewed |
| DC-R02-12W | 12 Dimensions of Wellness | Foundation | Client + Practitioner | PDF / Portal Reference | Resource Library | Yes | Yes | Purchased protocol users | v1.0 pending | Source reviewed |
| DC-R03-GLO | Distinct Character Framework Glossary | Foundation | Client + Practitioner | Portal Reference / PDF | Resource Library | Yes | Yes | Purchased protocol users | Draft needed | To create |
| DC-R04-BSI | Body Signal Index | Foundation | Client + Practitioner | Portal Reference / PDF | Resource Library | Yes | Yes | Purchased protocol users | Draft from BIC | To extract |
| DC-R05-NSG | Nervous System Governance Reference | Foundation | Client + Practitioner | Portal Reference / PDF | Resource Library | Yes | Yes | Purchased protocol users | Draft needed | To create |

## DC-P01-SBP Somatic Baseline Protocol

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P01-SBP-PC01 | Somatic Baseline Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P01-SBP-LTR01 | A Letter from Azari Solenne | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | Draft created | Add to protocol |
| DC-P01-SBP-AS01 | Somatic Dysregulation Index | Assessment | Client | Portal Tool + PDF | Protocol / Assessments | Yes | Yes | Review only | Needs cleanup | Source reviewed |
| DC-P01-SBP-ZONE01 | Nervous System Zone Selector | Tracker | Client | Portal Tool | Dashboard | Optional | Yes | Review only | Draft needed | To create |
| DC-P01-SBP-MAP01 | Environmental Friction Map | Worksheet | Client | Portal Tool + PDF | Protocol / Downloads | Yes | Yes | Review only | Source reviewed | Rebuild needed |
| DC-P01-SBP-TRK01 | Tactical Reset Practice Tracker | Tracker | Client | Portal Tool + PDF | Dashboard / Protocol | Yes | Yes | Review only | Source reviewed | Rebuild needed |
| DC-P01-SBP-LOG01 | Daily Governance Log | Ledger | Client | Portal Tool + PDF | Dashboard / Protocol | Yes | Yes | Review only | Source reviewed | Rebuild needed |
| DC-P01-SBP-LED01 | Relapse & Re-Entry Ledger | Ledger | Client | Portal Tool + PDF | Dashboard / Downloads | Yes | Yes | Practitioner review | Source reviewed | Rebuild needed |
| DC-P01-SBP-QR01 | Somatic Quick Reference | Quick Reference | Client | PDF + Portal Quick Card | Resource Library / Downloads | Yes | Optional | No | Source reviewed | Standardize design |
| DC-P01-SBP-RG01 | Somatic Trauma Resources Guide | Resource Guide | Client + Practitioner | PDF + Portal Reference | Resource Library | Yes | No | Optional | Source reviewed | Source/link cleanup |
| DC-P01-SBP-INT01 | Resource Integration Guide | Integration Guide | Client + Practitioner | PDF + Portal Reference | Resource Library | Yes | No | Optional | Source reviewed | Standardize wording |
| DC-P01-SBP-TA01 | Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Move to back |

## DC-P02-IOS Identity Operating System

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P02-IOS-PC01 | IOS-1 Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | Light | No | v1.0 pending | Rebuild needed |
| DC-P02-IOS-LTR01 | A Personal Welcome | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | User supplied | Add to protocol |
| DC-P02-IOS-CHK01 | IOS-1 Completion Checkpoints | Progress Tool | Client | Portal Tool | Protocol / Dashboard | No | Yes | Review only | Draft needed | To create |
| DC-P02-IOS-GATE01 | Diagnostic Verification Gate | Assessment Gate | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | To structure |
| DC-P02-IOS-SYN01 | Identity Synthesis Capture | Synthesis | Client | Portal Tool | Protocol | Optional | Yes | Practitioner review | Draft needed | To create |
| DC-P02-IOS-TRK01 | 30-Day Installation Tracker | Tracker | Client | Portal Tool + PDF | Dashboard / Downloads | Yes | Yes | Review only | Source reviewed | To structure |
| DC-P02-IOS-RG01 | Sovereign Framework Glossary | Reference | Client + Practitioner | PDF / Portal Reference | Resource Library | Yes | No | Yes | Source reviewed | Extract needed |
| DC-P02-IOS-TA01 | Session Directives for Clinical Partnership | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Gate as practitioner |

## DC-P02-MES Masking Economy System

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P02-MES-PC01 | MES-1 Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P02-MES-LTR01 | A Letter from Azari Solenne | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | User supplied | Add to protocol |
| DC-P02-MES-REG01 | Mask Registry | Portal Tool | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | To build |
| DC-P02-MES-CALC01 | Mask Cost Calculator | Calculator | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Review only | Source reviewed | To build |
| DC-P02-MES-MAP01 | ROI Efficiency Map | Matrix | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Review only | Source reviewed | To build |
| DC-P02-MES-BUD01 | Masking Budget Builder | Calculator | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Review only | Source reviewed | To build |
| DC-P02-MES-RET01 | Mask Retirement Protocol | Tracker | Client | Portal Tool + PDF | Dashboard / Downloads | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P02-MES-LED01 | Weekly Mask Audit Ledger | Ledger | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P02-MES-TA01 | MES-1 Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Draft needed | To create |

## DC-P02-NCS Narrative Control System

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P02-NCS-PC01 | NCS-1 Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P02-NCS-LTR01 | A Letter from Azari Solenne | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | User supplied | Add to protocol |
| DC-P02-NCS-PAT01 | Narrative Pattern Mapper | Portal Tool | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | Consolidate tables |
| DC-P02-NCS-DP01 | Seven Distortion Types Profile | Assessment | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Review only | Source reviewed | Keep as matrix |
| DC-P02-NCS-MAT01 | Narrative Audit Matrix | Matrix | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Review only | Source reviewed | Keep as matrix |
| DC-P02-NCS-OS01 | Override Script Library | Script Tool | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | Consolidate |
| DC-P02-NCS-APP01 | 14-Day Override Application Tracker | Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P02-NCS-WA01 | Weekly Narrative Audit | Ledger | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | Consolidate |
| DC-P02-NCS-TA01 | NCS-1 Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Gate as practitioner |

## DC-P03-EXE Execution Architecture Protocol

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P03-EXE-PC01 | Execution Architecture Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P03-EXE-LTR01 | A Letter from Azari Solenne | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | User supplied | Add to protocol |
| DC-P03-EXE-AUD01 | Somatic Execution Audit | Assessment | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | To build |
| DC-P03-EXE-DP01 | Decision Protocol Tool | Tool | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Review only | Source reviewed | To build |
| DC-P03-EXE-FR01 | Friction Reduction Map | Worksheet | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | To build |
| DC-P03-EXE-LOOP01 | Execution Loop Builder | Builder | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Review only | Source reviewed | To build |
| DC-P03-EXE-LED01 | Capacity Ledger | Ledger | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P03-EXE-TA01 | Execution Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Gate as practitioner |

## DC-P04-REL Relational Command Bundle

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P04-REL-BND01 | Relational Command Bundle Overview | Bundle Reference | Client + Practitioner | Portal Page + PDF | Protocol Start | Yes | Yes | Yes | Draft needed | To create |
| DC-P04-AUT-PC01 | Authority Framework Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild heavily |
| DC-P04-AUT-LTR01 | Authority Framework Personal Letter | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | Draft needed | To create |
| DC-P04-AUT-COM01 | Communication Persona Assessment | Assessment | Client | Portal Tool + PDF | Protocol | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-AUT-IC01 | Integrity Compass Filter | Tool | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | To build |
| DC-P04-AUT-RW01 | Weak Language Rewrite Tool | Tool | Client | Portal Tool + PDF | Protocol | Yes | Yes | Review only | Source reviewed | To build |
| DC-P04-AUT-SCR01 | Boundary / Soft Ask / Conflict Script Builder | Script Tool | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-AUT-TRK01 | 30-Day Soft Power Commitment Tracker | Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-AUT-TA01 | Authority Practitioner Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Draft needed | To create |
| DC-P04-ISC-PC01 | Internal Signal Calibration Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P04-ISC-LTR01 | Internal Signal Calibration Personal Letter | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | Draft needed | To create |
| DC-P04-ISC-ZONE01 | Zone 1 Readiness Check | Assessment | Client | Portal Tool | Protocol | Optional | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-ISC-MAT01 | Intuitive Decision Matrix | Matrix | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-ISC-LED01 | Allostatic Cost Ledger | Ledger | Client | Portal Tool + PDF | Dashboard / Downloads | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-ISC-MIC01 | Law of Titration Micro-Action Tracker | Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P04-ISC-TA01 | Internal Signal Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Gate as practitioner |

## DC-P06-SOV 30-Day Sovereignty Reset

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P06-SOV-PC01 | 30-Day Sovereignty Reset Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P06-SOV-LTR01 | 30-Day Sovereignty Reset Personal Letter | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | Draft needed | To create |
| DC-P06-SOV-BASE01 | Hard vs Soft Power Baseline Audit | Assessment | Client | Portal Tool + PDF | Protocol | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P06-SOV-TR01 | Daily Reset Tracker | Timed Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P06-SOV-BND01 | Boundary Execution Toolkit | Toolkit | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P06-SOV-DEC01 | Intuitive Decision Matrix | Matrix | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P06-SOV-ID01 | Identity Anchor Builder | Builder | Client | Portal Tool + PDF | Protocol | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P06-SOV-90D01 | 90-Day Integration Plan | Planner | Client | Portal Tool + PDF | Dashboard / Downloads | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P06-SOV-TA01 | Sovereignty Reset Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Gate as practitioner |

## DC-P07-SMB Self-Mastery Blueprint

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P07-SMB-PC01 | Self-Mastery Blueprint Printable Companion | Printable Companion | Client | PDF | Downloads | Yes | No | No | v1.0 pending | Rebuild needed |
| DC-P07-SMB-LTR01 | Self-Mastery Blueprint Personal Letter | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | Draft needed | To create |
| DC-P07-SMB-AS01 | Baseline / Closing Self-Assessment | Assessment | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-VIS01 | Governed Life Vision Builder | Builder | Client | Portal Tool + PDF | Protocol | Yes | Yes | Optional review | Source reviewed | To build |
| DC-P07-SMB-BRE01 | Breath Practice Tracker | Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-CBT01 | Cognitive Distortion Audit + Thought Record | Tool | Client | Portal Tool + PDF | Protocol | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-BIO01 | Food-Mood-Energy / Movement / Sleep Trackers | Tracker Suite | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-TIPP01 | T.I.P.P. + Crisis Response Log | Tracker | Client | Portal Tool + PDF | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-WA01 | Weekly Alignment Check-In | Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-DMA01 | Daily Micro-Adjustment Protocol | Tracker | Client | Portal Tool + PDF | Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-MP01 | Blueprint Master-Plan Builder | Builder | Client | Portal Tool + PDF Export | Protocol / Dashboard | Yes | Yes | Practitioner review | Source reviewed | To build |
| DC-P07-SMB-EX01 | Final Blueprint Export | Export | Client | Generated PDF | Downloads | Yes | Yes | Practitioner review | Draft needed | To create |
| DC-P07-SMB-TA01 | Self-Mastery Blueprint Therapeutic Addendum | Practitioner Resource | Practitioner | Portal Layer + PDF | Practitioner Layer | Yes | No | Yes | Source reviewed | Gate as practitioner |

## DC-P08-EIP Enterprise IP Mastermind

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Advisor Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-P08-EIP-PC01 | Enterprise IP Mastermind Executive Field Manual | Printable Companion | Client | PDF | Downloads | Yes | No | No | Draft needed | To create |
| DC-P08-EIP-LTR01 | Enterprise IP Mastermind Personal Letter | Front Matter | Client | Protocol page + PDF | Protocol Start | Yes | No | No | Draft needed | To create |
| DC-P08-EIP-READ01 | Commercial Readiness Assessment | Assessment | Client | Portal Tool + PDF | Enterprise IP | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-INV01 | IP Asset Inventory | Registry | Client | Portal Tool + PDF | Enterprise IP / Assets | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-FW01 | Framework Encoding Builder | Builder | Client | Portal Tool + PDF | Enterprise IP / Frameworks | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-CAT01 | Category Narrative Builder | Builder | Client | Portal Tool + PDF | Enterprise IP / Positioning | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-OFF01 | Offer Architecture Builder | Builder | Client | Portal Tool + PDF | Enterprise IP / Offers | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-PRICE01 | Pricing Mechanics Calculator | Calculator | Client | Portal Tool + PDF | Enterprise IP / Pricing | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-LIC01 | Licensing Rights Matrix | Matrix | Client | Portal Tool + PDF | Enterprise IP / Licensing | Yes | Yes | Legal review | Notes reviewed | To build |
| DC-P08-EIP-RISK01 | Risk Mitigation Disclosure Matrix | Matrix | Client | Portal Tool + PDF | Enterprise IP / Risk | Yes | Yes | Legal/Ops review | Notes reviewed | To build |
| DC-P08-EIP-SALES01 | Soft Power Sales System | Script / Sales Tool | Client | Portal Tool + PDF | Enterprise IP / Sales | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-ROAD01 | 12-Month Commercial Incubation Roadmap | Planner | Client | Portal Tool + PDF | Enterprise IP / Roadmap | Yes | Yes | Advisor review | Notes reviewed | To build |
| DC-P08-EIP-BRIEF01 | Final IP Commercialization Brief | Export | Client | Generated PDF | Downloads | Yes | Yes | Advisor review | Draft needed | To create |
| DC-P08-EIP-ADV01 | Commercial Facilitator / Legal-Ops Guide | Advisor Resource | Advisor / Admin | PDF + Portal Layer | Advisor Layer | Yes | No | Yes | Draft needed | To create |

## Masterclass / Expansion Layer

| Asset ID | Asset Title | Category | Audience | Format | Portal Location | Printable | Dashboard | Practitioner Layer | Version | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| DC-MC-ROOT | Masterclass Series | Expansion Layer | Client + Practitioner | Portal Section | Masterclass Series | Optional | Optional | Optional | Future | Placeholder |
| DC-P09-AAS | Advanced Application Series | Advanced Series | Client + Practitioner | Portal + PDF | Masterclass / Protocols | TBD | TBD | TBD | Future | Placeholder |

## Portal Dashboard Feature Register

| Feature ID | Feature | Related Assets | User Roles | Status |
|---|---|---|---|---|
| DASH-001 | Protocol Progress Timeline | All protocol IDs | Client, Practitioner, Admin, License Holder | To build |
| DASH-002 | Assessment Snapshot | AS assets | Client, Practitioner | To build |
| DASH-003 | Download Center | All printable/downloadable assets | All roles | To build |
| DASH-004 | Practitioner Client Review | TA assets + selected logs | Practitioner, Admin | To build |
| DASH-005 | License Holder Aggregate Reporting | SOV, SMB, EIP aggregates | License Holder, Admin | To build |
| DASH-006 | 30-Day Reset Cohort Dashboard | DC-P06-SOV assets | Client, Practitioner, License Holder, Admin | To build |
| DASH-007 | Self-Mastery Blueprint Capstone Dashboard | DC-P07-SMB assets | Client, Practitioner, Admin | To build |
| DASH-008 | Enterprise IP Portfolio Dashboard | DC-P08-EIP assets | Client, Advisor, Admin | To build |

## Resource Intake Workflow

When a new resource is uploaded, classify it as one of:

- Foundation Resource
- Protocol-Specific Worksheet
- Practitioner Resource
- Client Handout
- Licensing / Business Resource
- Masterclass / Expansion Asset
- Admin-Only Backend Resource
- Unknown / Classify

For each new asset, assign:

- Asset ID
- Title
- Parent protocol or resource category
- Audience
- Portal location
- Format
- Whether printable
- Whether downloadable
- Whether practitioner/advisor gated
- Dashboard relevance
- Version
- Status

## Status Definitions

| Status | Meaning |
|---|---|
| Source reviewed | Existing source has been inspected |
| Rebuild needed | Source exists but requires structural/design standardization |
| Rebuild heavily | Source needs substantial restructuring |
| To create | Asset does not exist yet |
| To extract | Asset exists inside a larger source and should be separated |
| To build | Portal-native version needed |
| Add to protocol | Content exists and needs insertion into standardized protocol |
| Gate as practitioner | Move or mark as practitioner-only in portal |
| Draft needed | New draft must be written |
| Future | Preserve architecture but do not build for MVP |
