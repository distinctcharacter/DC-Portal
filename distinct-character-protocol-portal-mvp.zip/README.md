# Distinct Character Protocol Portal MVP Prototype

This is a rough structural prototype for the Distinct Character Protocol Portal.

It is not production-ready. It exists to review the user experience, information architecture, protocol navigation, resource library structure, locked/unlocked states, and portal shell before the backend is implemented.

## What Is Included

- Next.js App Router scaffold
- Dashboard homepage
- Mock protocol library
- Locked and unlocked protocol cards
- One mocked protocol page: Somatic Baseline Protocol
- Resource Library
- Download Center
- Practitioner Layer placeholder
- Masterclass Series placeholder
- Progress tracker mockup
- Mobile responsive layout
- Supabase-ready code organization, without a Supabase connection
- Mock authentication and access state

## What Is Not Included

- Real authentication
- Supabase connection
- Stripe or checkout
- Real user data
- Real PDF download files
- Production deployment
- Full licensing infrastructure

## Local Setup

Install dependencies:

```bash
npm install
```

Run the local dev server:

```bash
npm run dev
```

Open:

```txt
http://localhost:3000
```

Build check:

```bash
npm run build
```

Type check:

```bash
npm run typecheck
```

## Folder Structure

```txt
app/
  layout.tsx
  page.tsx
  globals.css
  protocols/[slug]/page.tsx
components/
  AccessBadge.tsx
  AppShell.tsx
  DownloadTable.tsx
  ProgressTracker.tsx
  ProtocolCard.tsx
  ResourceCard.tsx
  SectionHeader.tsx
  StatCard.tsx
data/
  mock.ts
lib/
  access.ts
protocol-asset-register.md
netlify.toml
```

## Mock Access Model

The prototype uses local mock data in `data/mock.ts`.

Current mock state:

- Somatic Baseline Protocol is in progress.
- Cognitive Architecture and later protocols are locked.
- Enterprise IP Mastermind is marked as future.
- Practitioner-only assets appear locked to the mock client.

Access logic lives in `lib/access.ts`.

## Netlify Compatibility Notes

The project includes `netlify.toml`:

```toml
[build]
  command = "npm run build"
  publish = ".next"

[[plugins]]
  package = "@netlify/plugin-nextjs"
```

When deploying later:

- Connect the GitHub repo to Netlify.
- Set the production domain to `portal.distinctcharacter.com`.
- Add environment variables for Supabase and payment providers only when backend work begins.

## Future Supabase Integration Notes

Likely tables:

- `profiles`
- `protocols`
- `protocol_access`
- `protocol_phases`
- `phase_progress`
- `assessment_templates`
- `assessment_logs`
- `download_assets`
- `resource_assets`
- `practitioner_client_links`
- `cohorts`
- `protocol_runs`
- `licenses`

Initial replacement points:

- Replace `data/mock.ts` with Supabase queries.
- Replace `lib/access.ts` with entitlement checks using row-level security.
- Move practitioner visibility to role and assignment checks.
- Store assessment and tracker submissions in Supabase tables.

## Future Authentication Notes

Recommended path:

- Supabase Auth for email/password and magic link.
- Middleware route protection for portal pages.
- Role stored in `profiles`.
- Protocol entitlement stored separately from role.

Access should check both:

```txt
user role + active protocol entitlement
```

A practitioner role alone should not automatically grant visibility into all client data.

## Future Payment and Access Control Notes

Recommended path:

- Stripe Checkout or existing WordPress checkout integration.
- Webhook creates or updates `purchases`.
- Purchase grants `protocol_access`.
- Portal reads active access records at login.

Required access modes:

- Individual purchase
- Practitioner-guided access
- Cohort reset
- Licensed organization implementation
- Aggregate completion reporting

## Product Direction Guardrails

This is not a generic coaching portal.

The experience should remain:

- psychologically informed
- clinical-adjacent
- dark, premium, and structured
- oriented around behavioral governance
- low-friction and low cognitive load
- serious about therapeutic integration and future licensing

Avoid:

- wellness cliches
- pastel coaching UI
- influencer course aesthetics
- gamified self-help language
- pressure-based productivity copy

