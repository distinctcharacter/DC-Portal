export type Role = "client" | "practitioner" | "admin" | "license_holder";

export type ProtocolStatus = "available" | "locked" | "in_progress" | "completed" | "future";

export type Protocol = {
  id: string;
  slug: string;
  title: string;
  phase: string;
  type: "core" | "bundle" | "child" | "capstone" | "commercial" | "future";
  status: ProtocolStatus;
  completion: number;
  nextAction: string;
  description: string;
  requirements?: string[];
  children?: string[];
};

export type Resource = {
  id: string;
  title: string;
  category: string;
  protocol: string;
  audience: "Client" | "Practitioner" | "Client + Practitioner" | "Advisor";
  access: "Unlocked" | "Practitioner" | "Future";
  description: string;
};

export type DownloadAsset = {
  id: string;
  title: string;
  protocol: string;
  type: string;
  audience: string;
  status: "Available" | "Required" | "Locked" | "Updated";
};

export const mockUser = {
  name: "Azari Preview",
  role: "client" as Role,
  activeProtocol: "Somatic Baseline Protocol",
  currentPhase: "Section II: Biological Architecture"
};

export const protocols: Protocol[] = [
  {
    id: "DC-P01-SBP",
    slug: "somatic-baseline",
    title: "Somatic Baseline Protocol",
    phase: "Phase 1",
    type: "core",
    status: "in_progress",
    completion: 42,
    nextAction: "Complete the nervous system zone check and log one tactical reset.",
    description:
      "The biological foundation for behavioral governance. Establish nervous system literacy, baseline regulation, and a repeatable return-to-command practice."
  },
  {
    id: "DC-P02-COG",
    slug: "cognitive-architecture",
    title: "Cognitive Architecture",
    phase: "Phase 2",
    type: "bundle",
    status: "locked",
    completion: 0,
    nextAction: "Requires Somatic Baseline completion.",
    description:
      "A three-part identity and interpretation architecture: IOS-1, MES-1, and NCS-1.",
    requirements: ["Complete DC-P01-SBP", "Submit exit assessment"],
    children: ["IOS-1", "MES-1", "NCS-1"]
  },
  {
    id: "DC-P03-EXE",
    slug: "execution-architecture",
    title: "Execution Architecture Protocol",
    phase: "Phase 3",
    type: "core",
    status: "locked",
    completion: 0,
    nextAction: "Requires Cognitive Architecture completion.",
    description:
      "A behavioral operating system for consistent action without urgency, depletion, or emotional dependency.",
    requirements: ["Complete IOS-1", "Complete MES-1", "Complete NCS-1"]
  },
  {
    id: "DC-P04-REL",
    slug: "relational-command",
    title: "Relational Command",
    phase: "Phase 4",
    type: "bundle",
    status: "locked",
    completion: 0,
    nextAction: "Requires Execution Architecture completion.",
    description:
      "Authority Framework and Internal Signal Calibration: relational governance, soft power, and signal fidelity.",
    requirements: ["Complete DC-P03-EXE"],
    children: ["Authority Framework", "Internal Signal Calibration"]
  },
  {
    id: "DC-P06-SOV",
    slug: "sovereignty-reset",
    title: "30-Day Sovereignty Reset",
    phase: "Phase 6",
    type: "core",
    status: "locked",
    completion: 0,
    nextAction: "Requires Relational Command completion.",
    description:
      "A timed behavioral enforcement container that turns comprehension into daily biological and relational integration.",
    requirements: ["Complete Relational Command"]
  },
  {
    id: "DC-P07-SMB",
    slug: "self-mastery-blueprint",
    title: "Self-Mastery Blueprint",
    phase: "Capstone",
    type: "capstone",
    status: "locked",
    completion: 0,
    nextAction: "Requires 30-Day Sovereignty Reset final audit.",
    description:
      "The flagship capstone protocol: a guided life architecture command center for integrated self-mastery.",
    requirements: ["Complete 30-Day Final Audit"]
  },
  {
    id: "DC-P08-EIP",
    slug: "enterprise-ip-mastermind",
    title: "Enterprise IP Mastermind",
    phase: "Tier 3",
    type: "commercial",
    status: "future",
    completion: 0,
    nextAction: "Commercial incubation layer reserved for future activation.",
    description:
      "A high-ticket commercial incubation system for converting self-mastery into licensable intellectual property."
  }
];

export const resources: Resource[] = [
  {
    id: "DC-R01-BIC",
    title: "Biological Infrastructure Companion",
    category: "Foundation Resource",
    protocol: "Foundation",
    audience: "Client + Practitioner",
    access: "Unlocked",
    description:
      "A reference architecture for body, energy, recovery, and nervous system governance."
  },
  {
    id: "DC-R02-12W",
    title: "12 Dimensions of Wellness",
    category: "Foundation Resource",
    protocol: "Foundation",
    audience: "Client + Practitioner",
    access: "Unlocked",
    description:
      "A multidimensional map for reading physical, relational, identity, boundary, and self-efficacy signals."
  },
  {
    id: "DC-P01-SBP-QR01",
    title: "Somatic Quick Reference",
    category: "Quick Reference",
    protocol: "Somatic Baseline Protocol",
    audience: "Client",
    access: "Unlocked",
    description:
      "A low-friction guide for choosing the right SBP resource or reset path in the moment."
  },
  {
    id: "DC-P01-SBP-RG01",
    title: "Somatic Trauma Resources Guide",
    category: "Resource Guide",
    protocol: "Somatic Baseline Protocol",
    audience: "Client + Practitioner",
    access: "Unlocked",
    description:
      "Curated somatic trauma, polyvagal, and liberation-oriented resources for deeper study."
  },
  {
    id: "DC-P01-SBP-INT01",
    title: "Resource Integration Guide",
    category: "Integration Guide",
    protocol: "Somatic Baseline Protocol",
    audience: "Client + Practitioner",
    access: "Unlocked",
    description:
      "A practice bridge that tells users how to weave SBP companion resources into active protocol work."
  },
  {
    id: "DC-P01-SBP-TA01",
    title: "Somatic Baseline Therapeutic Addendum",
    category: "Therapeutic Addendum",
    protocol: "Somatic Baseline Protocol",
    audience: "Practitioner",
    access: "Practitioner",
    description:
      "Practitioner-facing safety, pacing, and clinical-adjacent implementation notes."
  }
];

export const downloads: DownloadAsset[] = [
  {
    id: "DC-P01-SBP-PC01",
    title: "Somatic Baseline Printable Companion",
    protocol: "Somatic Baseline Protocol",
    type: "Printable Companion",
    audience: "Client",
    status: "Available"
  },
  {
    id: "DC-P01-SBP-AS01",
    title: "Somatic Dysregulation Index",
    protocol: "Somatic Baseline Protocol",
    type: "Assessment",
    audience: "Client",
    status: "Required"
  },
  {
    id: "DC-P01-SBP-LOG01",
    title: "Daily Governance Log",
    protocol: "Somatic Baseline Protocol",
    type: "Ledger",
    audience: "Client",
    status: "Available"
  },
  {
    id: "DC-P01-SBP-TA01",
    title: "Therapeutic Addendum",
    protocol: "Somatic Baseline Protocol",
    type: "Practitioner Resource",
    audience: "Practitioner",
    status: "Locked"
  },
  {
    id: "DC-P07-SMB-EX01",
    title: "Final Blueprint Export",
    protocol: "Self-Mastery Blueprint",
    type: "Generated Export",
    audience: "Client",
    status: "Locked"
  }
];

export const sbpSections = [
  {
    id: "orientation",
    title: "Orientation",
    status: "completed",
    summary:
      "Protocol scope, safety framing, and the role of biological stability in the larger ecosystem."
  },
  {
    id: "baseline-assessment",
    title: "SDI Baseline Assessment",
    status: "completed",
    summary:
      "A structured baseline reading across sympathetic, dorsal, and fawn response patterns."
  },
  {
    id: "biological-architecture",
    title: "Biological Architecture",
    status: "in_progress",
    summary:
      "The internal mechanics of neuroception, state shifts, and the three-zone operating model."
  },
  {
    id: "vagus-nerve",
    title: "The Vagus Nerve",
    status: "available",
    summary:
      "Vagal tone, recovery capacity, and daily practices for returning to command."
  },
  {
    id: "environmental-audit",
    title: "Environmental Audit",
    status: "locked",
    summary:
      "A structured map of friction sources, body signals, and remove/restructure/regulate decisions."
  },
  {
    id: "tactical-resets",
    title: "Tactical Reset Protocols",
    status: "locked",
    summary:
      "A set of practical interventions for acute activation, shutdown, and capacity recovery."
  }
];
