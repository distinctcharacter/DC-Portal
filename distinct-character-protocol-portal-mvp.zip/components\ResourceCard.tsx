import type { Resource } from "@/data/mock";

export function ResourceCard({ resource }: { resource: Resource }) {
  return (
    <article className="resource-card">
      <div className="card-topline">
        <span className="protocol-id">{resource.id}</span>
        <span className={`resource-access ${resource.access.toLowerCase()}`}>{resource.access}</span>
      </div>
      <h3>{resource.title}</h3>
      <p>{resource.description}</p>
      <dl>
        <div>
          <dt>Category</dt>
          <dd>{resource.category}</dd>
        </div>
        <div>
          <dt>Audience</dt>
          <dd>{resource.audience}</dd>
        </div>
      </dl>
    </article>
  );
}
