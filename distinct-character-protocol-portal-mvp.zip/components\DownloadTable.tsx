import type { DownloadAsset } from "@/data/mock";

export function DownloadTable({ assets }: { assets: DownloadAsset[] }) {
  return (
    <div className="download-table" role="table" aria-label="Download center assets">
      <div className="download-row header" role="row">
        <span>Asset</span>
        <span>Protocol</span>
        <span>Type</span>
        <span>Status</span>
      </div>
      {assets.map((asset) => (
        <div className="download-row" role="row" key={asset.id}>
          <span>
            <strong>{asset.title}</strong>
            <small>{asset.id}</small>
          </span>
          <span>{asset.protocol}</span>
          <span>{asset.type}</span>
          <span className={`download-status ${asset.status.toLowerCase()}`}>{asset.status}</span>
        </div>
      ))}
    </div>
  );
}
